class Greeting:
    def say_hi(self, name):
        print(f"hello, {name}!")

a = Greeting()        
a.say_hi("World")
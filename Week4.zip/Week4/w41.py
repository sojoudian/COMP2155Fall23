from someFile import className

className.method()

a = "hello"
print(a.upper())